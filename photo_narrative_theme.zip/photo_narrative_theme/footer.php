    </div><!-- /.container -->


    <footer class="footer">
      <div class="toTop">
        <a href="#"><i class="fas fa-chevron-up"></i></a>
      </div>

      <div class="footerMain">
        <table>
          <tbody>
            <tr>
              <th>Get in touch</th>
              <td>
                <ul>
                  <li><a class="instagram" href="<?php echo get_option('instagram'); ?>"><i class="fab fa-instagram"></i></a></li>
                  <li><a class="twitter" href="<?php echo get_option('twitter'); ?>"><i class="fab fa-twitter-square"></i></a></li>
                  <li><a class="facebook" href="<?php echo get_option('facebook'); ?>"><i class="fab fa-facebook-square"></i></a></li>
                </ul>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="subfooter">
        <p>2017-2018 Nicole Cyhelka | All Rights Reserved</p>
      </div>
    </footer>

    <?php wp_footer(); ?>
  </body>
</html>

    <!--
      <p>
        <a href="#">Back to top</a>
      </p>

      <ul>
        <li><a href="<?php //echo get_option('instagram'); ?>">Instagram</a></li>
        <li><a href="<?php //echo get_option('twitter'); ?>">Twitter</a></li>
        <li><a href="<?php //echo get_option('facebook'); ?>">Facebook</a></li>
      </ul>
  -->