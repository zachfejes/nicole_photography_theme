    </div><!-- /.container -->


    <footer class="blog-footer">
      <p>Blog template built for <a href="http://getbootstrap.com">Bootstrap</a> by <a href="https://twitter.com/mdo">@mdo</a>.</p>
      <p>
        <a href="#">Back to top</a>
      </p>

      <ul>
        <li><a href="<?php echo get_option('instagram'); ?>">Instagram</a></li>
        <li><a href="<?php echo get_option('twitter'); ?>">Twitter</a></li>
        <li><a href="<?php echo get_option('facebook'); ?>">Facebook</a></li>
      </ul>

    </footer>

    <?php wp_footer(); ?>
  </body>
</html>